import java.util.*;

public class EconomyPassenger extends Passenger {
	
	private String flightNo;
	private String passengerID;
	private String name;
	private String passengertype;
	private String mealType;
	
	   public EconomyPassenger(String flightNo,String passengerID,String name, String mealType)
	   {
		super(flightNo,passengerID,name);
	   	
	   this.mealType = mealType;
	   }
	   public double checkInBaggage(double weight) 
		 {
			super.checkInBaggage(weight);
				   return super.extra;
			 
			  
		  }
	   public void print()
	   {
	     super.print();
	     System.out.printf("%-20s%s\n", "Meal Type:", mealType);
	   }
	   }
