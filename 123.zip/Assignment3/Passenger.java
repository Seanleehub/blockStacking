
public class Passenger{
	private String flightNo;
	private String passengerID;
	private String name;
	private String passengertype;
	double extra;
	   public Passenger(String flightNo,String passengerID,String name)
	   {
		   this. flightNo = flightNo;
		   this.passengerID = passengerID;
		   this.name = name;
   
	   	}
	
	
	 public double checkInBaggage(double weight)  
	
	 {
		
		 if(weight > 15 && weight < 20 ){
			extra =  (weight - 15)*20;
		 }
		 else if(weight > 20){
			extra = (weight - 20)* 20;
		 }
		 else{
			 
			 extra = 0.00;
		 }
		 return extra;
	  }
	  
	   public String passsengerID()
	   {
		   return passengerID;
	   }
	   public void print()
	   {
	      System.out.printf("%-20s%s\n", "Flight No:", flightNo);
	      System.out.printf("%-20s%s\n", "Passenger ID:", passsengerID());
	      System.out.printf("%-20s%s\n", "Name:", name);
	   }
	   }
