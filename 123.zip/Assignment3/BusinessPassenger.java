
public class BusinessPassenger extends Passenger {

	private String flightNo;
	private String passengerID;
	private String name;
	private String passengertype;
	
	   public BusinessPassenger(String flightNo,String passengerID,String name)
	   {
		super(flightNo,passengerID,name);
	   	}
	  
	   
	   public double checkInBaggage(double weight) 
		 {
		   super.checkInBaggage(weight);
		   return super.extra;
			  
		  }
	 
	   public void print()
	   {
	     super.print();
	   }
}
