//Assuming all user input are correct as in time should have a : splitter and FLIGHT NUMBER is in the format QQ111 with capital letters and 3 numbers at the back.
import java.util.Scanner;

public class ManageFlights
{

  
   private static Flight[] flights = new Flight[100];
   private static Flight[] Rflights = new Flight[100];
   
  
   private static Scanner sc = new Scanner(System.in);

   public static void main(String[] args)
   {
     
      createFlights();
    

      
      String input;
      char option = ' ';

      do
      {
         System.out.printf("\n%18s\n", "Flight Menu");
         System.out.printf("%-25s%d\n", "Display All Flights", 1);
         System.out.printf("%-25s%d\n", "Open Flight", 2);
         System.out.printf("%-25s%d\n", "Book seats on a Flight", 3);
         System.out.printf("%-25s%d\n", "Close Flight", 4);
         System.out.printf("%-25s%d\n", "Delay Flight", 5);
         System.out.printf("%-25s%d\n", "Create A FLight", 6);
         System.out.printf("%-25s%d\n\n", "Exit", 7);
        
         System.out.print("Enter your selection: ");
        
         input = sc.nextLine();
         
         if (input.length() == 1)
         {
            option = input.charAt(0);
            
            switch(option)
            {
               case '1':
            	  try{
                  viewAllFlights();
                  break;
            	  }catch (Exception e){System.out.println("");}
               case '2':
                  openFlight();
                  break;
                  
               case '3':
                  reserveSeats();
                  break;
                  
               case '4':
                  closeFlight();
                  break;
                  
               case '5':
                  delayFlight();
                  break;
               case '6':
                  inputFlight();
                   break;
               case '7':
                  System.out.println("Have a nice day.  :)");
                  break;
                  
               default:
                  System.out.printf(
                        "Error - %c is not a valid option, please try again.",
                        option);
            }
         }
      } while (option != '7');
   }

  
   private static void createFlights()
   {
	   
      Rflights[0] = new Flight("QR511", "Sydney", "Newcastle",
            1.00, "1/1/2011", "14:00", 80);
     Rflights[1] = new Flight("QR613", "Perth", "Broome", 4.00,
            "1/1/2011", "17:30", 100);

      flights[0] = new Flight("QJ101", "Melbourne", "Sydney", 2.00, "1/1/2011",
            "08:00", 80);

      flights[1] = new Flight("QJ302", "Melbourne", "Brisbane", 3.50,
            "1/1/2011", "09:00", 100);

      flights[2] = new RegionalFlight("QJ510", "Melbourne", "Sydney", 2.00,
            "1/1/2011", "10:00", 80, Rflights[0]);

      flights[3] = new RegionalFlight("QR612", "Melbourne", "Perth", 5.00,
            "1/1/2011", "11:00", 100, Rflights[1]);

      flights[4] = new Flight("QJ303", "Brisbane", "Melbourne", 4.00,
            "1/1/2011", "12:00", 100);

      flights[5] = new Flight("QJ102", "Sydney", "Melbourne", 2.50, "1/1/2011",
            "15:30", 100);
     
   }

 
   public static Flight getFlight(String flightNo)
   {
      Flight f = null;

      for (int i = 0; i < flights.length; i++)
      {
         if (flights[i].getFlightNo().equals(flightNo))
         {
            f = flights[i];
         }
      }
      return f;
   }
   // Flights will be inputed to array as long as user does not re-choose the Create A flight which is option 6 because it will reset the data into the first array that is not hard coded by me.
   public static void inputFlight()
   {
	   int userChoice;
	   int y = 6;
	   int l = 3;
	   do
	   {
		   
		     System.out.printf("\n%18s\n", "Please Choose Flight Type:");
	         System.out.printf("%-25s%d\n", "Flight", 1);
	         System.out.printf("%-25s%d\n", "Regional Flight", 2);
	         System.out.printf("%-25s%d\n", "Exit", 0);
	         System.out.print("Enter your selection: ");
	         userChoice = sc.nextInt();
	         
	         switch (userChoice) {
     
	         case 1:
	        	 String fno;
	        	 String dep;
	        	 String dest;
	        	 String time;
	        	 String fdate;
	        	 int fca;
	        	 String fle;
	        	
	        	 System.out.println("You have chosen to create a new FLIGHT");
	        	
	        	 	System.out.println("Please Enter the Flight No: ");
	        	  	fno = sc.next();
	        	
	        	  		try{
	        	  		boolean result = uniqueFlightNo(fno);

	        	  		if(result == true){
	        	  			
	        	  			System.out.println("The Flight Number is VALID :"+ fno);
	        	  			
	        	  			
	        	  		}else{
	        	  			System.out.println("The Flight Number entered is INVALID due to another flight with the same FLIGHT number :"+ fno);
	        	  			break;
	        	  			
	        	  		}
	        	  		}catch (Exception e){System.out.println("The Flight Number is VALID");}
	        	  	System.out.println("Please Enter the Departing City: ");
	        	  	dep = sc.next();
	        	  
	        	  	System.out.println("Please Enter the Destination: ");
	        	  	dest = sc.next();
	        	  	 System.out.println("Please Enter the Flight Length: ");
	        		  fle = sc.next();
	        		  double aDouble3 = Double.parseDouble(fle);
	        	  	
	        	 
	        		  System.out.println("Please Enter the Departure Time: ");
	        		  time = sc.next();
	        		  try{
	        		 		boolean pop = arrivalTime( time, aDouble3 );
	        		 	
	        		 	if(pop == true){
	        	  			System.out.println("Arrival Time is not past Mid-Night. Arrival Time is : " + arrivalTime2(  time, aDouble3  ) );
	        	  		}	else{
	        	  			System.out.println("The Arrival Time is Past Mid-Night Flight cannot be Created");
	        	  			break;
	        	  			
	        	  		}
	        			}catch (Exception e){System.out.println("Departure Time is Invalid!!");}
	        		try{
	        			
	        			boolean result3 = timeformat(time);
	        	  		if( result3 == true){
	        	  			
	        	  			System.out.println("Time format is Correct Please Procceed: "+ time);
	        	  			
	        	  			
	        	  		}else{
	        	  			System.out.println("The time format is INVALID. It must have 5 characters, have a : symbol and must be before Mid-Night: "+ time);
	        	  			break;
	        	  			
	        	  		}
	        	  		
	        	  		
        		 	}catch (Exception e){System.out.println("Departure Time is Invalid!!");}
        		 	
        		 	
	        		
	        	
	        		  System.out.println("Please Enter the Flight Date: ");
	        		  fdate = sc.next();
	        	 
	        		 
	        		  
	        		  System.out.println("Please Enter the Capacity: ");
	        	  		fca = sc.nextInt();
	        	  	
	        	  			
	        	  			flights[y] = new Flight(fno,dep,dest,aDouble3,fdate,time,fca);	
	        	  			y++;
	        	 break;
	        	
	        	 
	        	 
   	
	        	
	         case 2:
    	   
	        	 String fno2;
	        	 String dep2;
	        	 String dest2;
	        	 String time2;
	        	 String fdate2;
	        	
	        	
	        	 int fca2;
	        	 String fle2;
	        	 System.out.println("You have chosen to create a new REGIONAL FLIGHT");
	        	 
	        	
	        	 	System.out.println("Please Enter the Flight No: ");
	        	  	fno2 = sc.next();
	        		try{
	        	  		boolean result = uniqueFlightNo(fno2);

	        	  		if(result == true){
	        	  			
	        	  			System.out.println("The Flight Number is VALID :"+ fno2);
	        	  			
	        	  			
	        	  		}else{
	        	  			System.out.println("The Flight Number entered is INVALID due to another flight with the same FLIGHT number :"+ fno2);
	        	  			break;
	        	  			
	        	  		}
	        	  		}catch (Exception e){System.out.println("The Flight Number is VALID");}
	        	  
	        	  	System.out.println("Please Enter the Departing City: ");
	        	  	dep2 = sc.next();
	        	  
	        	  	System.out.println("Please Enter the Destination: ");
	        	  	dest2 = sc.next();
	        	  
	        	  	
	        	  	System.out.println("Please Enter the Flight Length: ");
	        	  	fle2 = sc.next();
	        	  	 double aDouble = Double.parseDouble(fle2);
	        	  	System.out.println("Please Enter the Departure Time: ");
	        	  	time2 = sc.next();
	        	  	 try{
	        		 		boolean pop1 = arrivalTime( time2, aDouble );
	        		 	
	        		 	if(pop1 == true){
	        	  			System.out.println("Arrival Time is not past Mid-Night. Arrival Time is : " + arrivalTime2(  time2, aDouble  ) );
	        	  		}	else{
	        	  			System.out.println("The Arrival Time is Past Mid-Night Flight cannot be Created");
	        	  			break;
	        	  			
	        	  		}
	        			}catch (Exception e){System.out.println("Departure Time is Invalid!!");}
	        	  		try{
	        			
	        			boolean result3 = timeformat(time2);
	        	  		if( result3 == true){
	        	  			
	        	  			System.out.println("Time format is Correct Please Procceed: "+ time2);
	        	  			
	        	  			
	        	  		}else{
	        	  			System.out.println("The time format is INVALID. It must have 5 characters, have a : symbol and must be before Mid-Night: "+ time2);
	        	  			break;
	        	  			
	        	  		}
        		 	}catch (Exception e){System.out.println("Departure Time is Invalid!!");}
	        		
	        	 
	        	  	
	        	  	
	  	
	        	  	System.out.println("Please Enter the Flight Date: ");
	        	  	fdate2 = sc.next();
	        	
	        	  	
	        		  
	        	  	System.out.println("Please Enter the Capacity: ");
	        	  	fca2 = sc.nextInt();
	        	  	
	        	  	System.out.println("Please Enter the Details Of the Connecting Flight:");
	        	 	String fno3;
	        	 	String dep3;
	        	 	String dest3;
	        	 	String time3;
	        	 	
	        	 	String fle3;
	        	 
	        	 
	        	
	        	 	System.out.println("Please Enter the Flight No of the Connecting Flight: ");
	        	  	fno3 = sc.next();
	        	  	
	        		try{
	        	  		boolean result = uniqueFlightNo2(fno3);

	        	  		if(result == true){
	        	  			
	        	  			System.out.println("The Flight Number is VALID :"+ fno3);
	        	  			
	        	  			
	        	  		}else{
	        	  			System.out.println("The Flight Number entered is INVALID due to another flight with the same FLIGHT number :"+ fno3);
	        	  			break;
	        	  			
	        	  		}
	        	  		}catch (Exception e){System.out.println("The Flight Number is VALID");}
	        	  
	        	  	System.out.println("Please Enter the Departing City of the Connecting Flight: ");
	        	  	dep3 = sc.next();
	        	  
	        	  	System.out.println("Please Enter the Destination of the Connecting Flight: ");
	        	  	dest3 = sc.next();
	        	  
	        	  	 System.out.println("Please Enter the Flight Length: ");
	        		  fle3 = sc.next();
	        		 
	        		  double aDouble2 = Double.parseDouble(fle3);
	        	  	
	        		  System.out.println("Please Enter the Departure Time of the Connecting Flight: ");
	        		  time3 = sc.next();
	        		  try{
	        		 		boolean pop1 = arrivalTime( time3, aDouble2 );
	        		 	
	        		 	if(pop1 == true){
	        	  			System.out.println("Arrival Time is not past Mid-Night. Arrival Time is : " + arrivalTime2(  time3, aDouble2  ) );
	        	  		}	else{
	        	  			System.out.println("The Arrival Time is Past Mid-Night Flight cannot be Created");
	        	  			break;
	        	  			
	        	  		}
	        			}catch (Exception e){System.out.println("Departure Time is Invalid!!");}
	        		  try{
		        			
		        			boolean result3 = timeformat(time3);
		        	  		if( result3 == true){
		        	  			
		        	  			System.out.println("Time format is Correct Please Procceed: "+ time3);
		        	  			
		        	  			
		        	  		}else{
		        	  			System.out.println("The time format is INVALID. It must have 5 characters, have a : symbol and must be before Mid-Night: "+ time3);
		        	  			break;
		        	  			
		        	  		}
	        		 	}catch (Exception e){System.out.println("Departure Time is Invalid!!");}
	        		
    	 
	        		 
	        		  
      	  		
	        	  		Rflights[l] =  new Flight(fno3, dep3, dest3,
	        	  	            aDouble2, fdate2, time3, fca2);
	        	  		flights[y] = new RegionalFlight(fno2, dep2, dest2, aDouble,
	        	  	            fdate2, time2, fca2, Rflights[l]);	
	        	  		l++;
	        	  		y++;
	        	  		
	        	 break;
  
       default:
             System.out.println("Invalid Number.");
             break;
       }  
       System.out.println();
     
	   } while (userChoice != 0);
	   System.out.println("Bye!");

   }
 
   public static boolean uniqueFlightNo2(String fno)
   {
     for (int i = 0; i < flights.length;i ++)
     {
     if (Rflights[i].getFlightNo().compareTo(fno)== 0)
       {
         return false;
         
       }
     }
     return true; 
   }
   public static boolean uniqueFlightNo(String fno)
   {
     for (int i = 0; i < flights.length;i ++)
     {
     if (flights[i].getFlightNo().compareTo(fno)== 0)
       {
         return false;
         
       }
     }
     return true; 
   
   }
  
   public static boolean timeformat(String fno)
   { 
	   int hours = Integer.parseInt(fno.substring(0,2)); 
	   
   int as = fno.length();
   if(hours > 24){
	
	   return false;
   }else if(as !=5 ){
  	 
  	 return false;
   }
   else if(fno.indexOf(":")!= 2){
  	 return false;
   }
   else{
  	 return true;
   }
   
   }
   
   public static boolean arrivalTime(String arv, double doub ){
	   
 	  int hours = Integer.parseInt(arv.substring(0,2));
 	  int minutes = Integer.parseInt(arv.substring(3,5));
 	  
 	  int hoursmin = hours * 60;
 	  int minutesmin = minutes;
 	  
 	  int allmins = hoursmin + minutesmin;
 	  double flightlength = (doub *60) + allmins;
 	 
 	  double flightlengthfinal = flightlength / 60;
 	 
 	  if (flightlengthfinal> 24){
 		  return false;
 	  }else{
 		  return true;
 		  }
 	 
 	  
   }
   
   public static double arrivalTime2(String arv, double doub ){
	   		double flightlengthfinal = 0;
	 	  int hours = Integer.parseInt(arv.substring(0,2));
	 	  int minutes = Integer.parseInt(arv.substring(3,5));
	 	  
	 	  int hoursmin = hours * 60;
	 	  int minutesmin = minutes;
	 	  
	 	  int allmins = hoursmin + minutesmin;
	 	  double flightlength = (doub *60) + allmins;
	 	 
	 	 flightlengthfinal = flightlength / 60;
	 	 
	 	  if (flightlengthfinal< 24){
	 		
	 		  return flightlengthfinal;
	 		  
	 	  }else{
	 		  return 0.00;
	 	  }
	 	 
	 	  
	   }



 
public static void viewAllFlights() throws Exception
   {
      System.out.printf("\n%65s\n\n", "(Current Flight Schedule)");
      System.out.printf("%-13s", "Flight No.");
      System.out.printf("%-15s", "Departing");
      System.out.printf("%-15s", "Destination");
      System.out.printf("%-7s", "Time");
      System.out.printf("%-11s", "Date");
      System.out.printf("%8s", "Length");
      System.out.printf("%10s", "Capacity");
      System.out.printf("%11s", "Bookings");
      System.out.printf("%12s", "Status");
      System.out.printf("%9s\n", "Layover");
      
      System.out.printf("%-13s%-15s%-15s%-7s%-11s%8s%10s%11s%12s%9s\n",
            "-----------", "----------", "------------", "-----", "---------",
            "------", "--------", "--------", "---------", "-------");
      
    
      for (int i = 0; i < flights.length; i++)
      {
     if(flights[i].getFlightNo()!= null){
    	 
         flights[i].printInRow();
         System.out.println();
         System.out.println();
         
    		
    	}
     else{
    	 break;
     }
      }
   }

   public static void openFlight()
   {
      Flight flight;
      String flightID;

      System.out.print("\nEnter id of flight to open: ");
      flightID = sc.nextLine();

      flight = getFlight(flightID);

      if (flight == null)
      {
         System.out.printf("\nError - flight %s not found!\n", flightID);
      }
      else
      {
    	  try
    	  {
         boolean result = flight.open();
         if (result == true)
         {
            System.out.printf("\nFlight %s opened for boarding.\n", flightID);
         }
         else
         {
            System.out.printf(
                  "\nError flight %s cannot be opened for boarding!\n", 
                  flightID);
         }
    	  }catch (Exception e){System.out.println(e.getMessage());}
    	
    	

      }
   }

   public static void reserveSeats()
   {
      Flight flight;
      String flightID;

      System.out.print("\nEnter id of flight to open: ");
      flightID = sc.nextLine();

      flight = getFlight(flightID);

      if (flight == null)
      {
         System.out.printf("\nError - flight %s not found!\n", flightID);
      }
      else
      {
    	  try
    	  {
         System.out.print("\nEnter number of seats to reserve: ");
         int seats = sc.nextInt();

         boolean result = flight.reserveSeats(seats);

         if (result == true)
         {
            System.out.printf("\n%d seats for flight %s reserved.\n", seats,
                  flightID);
         }
         else
         {
            System.out.printf(
                  "\nError cannot reserve %d seats for flight %s!\n",
                  seats, flightID);
         }
    	  }
    	  catch (Exception e){System.out.println(e.getMessage());  }
      }
   }

   public static void closeFlight()
   {
      Flight flight;
      String flightID;

      System.out.print("\nEnter id of flight to close: ");
      flightID = sc.nextLine();

      flight = getFlight(flightID);

      if (flight == null)
      {
         System.out.printf("\nError - flight %s not found!\n", flightID);
      }
      else
      {
       try{
         boolean result = flight.close();

         if (result == true)
         {
            System.out.printf(
                  "\nFlight \"%s\" closed for departure.\n", 
                  flightID);
         }
         else
         {
            System.out.printf(
                  "\nError - flight \"%s\" cannot be closed for departure!\n",
                  flightID);
         }}
         catch (Exception e){System.out.println(e.getMessage());}
    	
      }

      
     
   }
   
   public static void delayFlight()
   {
      Flight flight;
      String flightID;

      System.out.print("\nEnter id of flight to Delay: ");
      flightID = sc.nextLine();

      flight = getFlight(flightID);

      if (flight == null)
      {
         System.out.printf("\nError - flight %s not found!\n", flightID);
      }
      else
    	
      {
    	
         System.out.print("\nEnter delay hours: ");
         int hours = sc.nextInt();

         System.out.print("\nEnter delay minutes: ");
         int minutes = sc.nextInt();
         try{
         boolean result = flight.delay(hours, minutes);

         if (result == true)
         {
            if (flight.getStatus() == 'C')
            {
               System.out.printf(
                     "\nFlight %s has been cancelled due to delays.\n");
            }
            else
            {
               System.out.printf("\nFlight %s has been delayed until %s hours.\n",
                     flightID, flight.getFlightTime());
            }
         }
         else
         {
            System.out.printf(
                  "\nError - flight \"%s\" cannot be delayed\n!",
                  flightID);
         }

      }catch (Exception e){System.out.println(e.getMessage());}
      }
   }
   
}